import os
import openai
from aiogram import Bot, Dispatcher, executor, types
from gtts import gTTS
from pydub import AudioSegment

# API kalitlarni olish (Replit Secrets ga qo'shing)
TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")

if not TELEGRAM_TOKEN or not OPENAI_API_KEY:
    raise RuntimeError("Iltimos, TELEGRAM_TOKEN va OPENAI_API_KEY ni Replit Secrets ga qo‘shing!")

# Bot va OpenAI sozlamalari
bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher(bot)
openai.api_key = OPENAI_API_KEY

# Har bir foydalanuvchi uchun chat tarixi (xotira asosida, oddiy)
user_histories = {}

async def ask_openai(user_id, text):
    history = user_histories.get(user_id, [])
    history.append({ "role": "user", "content": text })

    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[
            { "role": "system", "content": "Siz foydalanuvchilarga o'zbek tilida yordam beruvchi samimiy sun'iy intellekt botsiz." }
        ] + history,
        temperature=0.8,
        max_tokens=800
    )

    answer = response["choices"][0]["message"]["content"]

    # Tarixni yangilash va oxirgi 10 xabarni saqlash
    history.append({ "role": "assistant", "content": answer })
    user_histories[user_id] = history[-10:]
    return answer


@dp.message_handler(commands=['start', 'help'])
async def start(message: types.Message):
    await message.reply(
        "Salom! 🤖\n"
        "Men sun'iy intellektli o'zbekcha botman.\n\n"
        "Matn yoki ovoz yuboring — men javob beraman!\n\n"
        "/clear — suhbat tarixini tozalash"
    )


@dp.message_handler(commands=['clear'])
async def clear_history(message: types.Message):
    user_histories.pop(message.from_user.id, None)
    await message.reply("Suhbat tarixi tozalandi 🧹")


@dp.message_handler(content_types=types.ContentType.TEXT)
async def handle_text(message: types.Message):
    user_id = message.from_user.id
    response = await ask_openai(user_id, message.text or "")

    # Matnli javob
    await message.reply(response)

    # Ovozli javob (TTS) - gTTS yordamida mp3 yaratib OGG ga aylantiramiz
    try:
        tts = gTTS(text=response, lang='uz')
        mp3_file = f"reply_{user_id}.mp3"
        ogg_file = f"reply_{user_id}.ogg"
        tts.save(mp3_file)

        sound = AudioSegment.from_mp3(mp3_file)
        sound.export(ogg_file, format="ogg")

        with open(ogg_file, 'rb') as voice:
            await message.reply_voice(voice)

    except Exception as e:
        await message.reply("Ovozli javobni yaratishda xatolik yuz berdi.")
        print("TTS error:", e)
    finally:
        # Tozalash
        for f in (mp3_file, ogg_file):
            try:
                if os.path.exists(f):
                    os.remove(f)
            except:
                pass


@dp.message_handler(content_types=types.ContentType.VOICE)
async def handle_voice(message: types.Message):
    # Ovozni yuklab olish
    file_info = await bot.get_file(message.voice.file_id)
    file_path = file_info.file_path
    file_bytes = await bot.download_file(file_path)

    input_ogg = f"input_{message.from_user.id}.ogg"
    with open(input_ogg, 'wb') as f:
        f.write(file_bytes.read() if hasattr(file_bytes, 'read') else file_bytes)

    try:
        # Ovozdan matnga o‘tkazish (Whisper-1)
        with open(input_ogg, "rb") as audio_file:
            transcript = openai.Audio.transcribe("whisper-1", audio_file)
        user_text = transcript.get("text", "").strip()

        if not user_text:
            await message.reply("Ovozdan matn olinmadi. Iltimos, qayta yuboring.")
            return

        response = await ask_openai(message.from_user.id, user_text)
        await message.reply(f"🗣 Siz dedingiz: {user_text}\n\n🤖 Javob: {response}")

        # Javobni ovozda yuborish
        try:
            tts = gTTS(text=response, lang='uz')
            mp3_file = f"reply_{message.from_user.id}.mp3"
            ogg_file = f"reply_{message.from_user.id}.ogg"
            tts.save(mp3_file)
            sound = AudioSegment.from_mp3(mp3_file)
            sound.export(ogg_file, format="ogg")
            with open(ogg_file, 'rb') as voice:
                await message.reply_voice(voice)
        except Exception as e:
            await message.reply("Javobni ovozga aylantirishda xatolik yuz berdi.")
            print("TTS error:", e)

    except Exception as e:
        await message.reply("Ovozli xabarni tahlil qilishda xatolik yuz berdi ❌")
        print("Transcription error:", e)
    finally:
        # Fayllarni o'chirish
        for f in [input_ogg, f"reply_{message.from_user.id}.mp3", f"reply_{message.from_user.id}.ogg"]:
            try:
                if os.path.exists(f):
                    os.remove(f)
            except:
                pass


if __name__ == "__main__":
    print("🤖 Bot ishga tushdi...")
    executor.start_polling(dp, skip_updates=True)
