# Uzbek AI Telegram Bot 🤖🇺🇿

Muallif: @zhodilov

Bu loyiha OpenAI GPT-3.5 (gpt-3.5-turbo) va Whisper-1'dan foydalanib, foydalanuvchi bilan o'zbek tilida
matn va ovoz orqali muloqot qiluvchi Telegram bot yaratadi.

## Qanday ishlatish
1. Replit yoki mahalliy serverda yangi Python loyiha yarating.
2. `requirements.txt` dagi kutubxonalarni o'rnating:
   ```
   pip install -r requirements.txt
   ```
3. Replit yoki muhitga `TELEGRAM_TOKEN` va `OPENAI_API_KEY` ni Secrets (Environment variables) orqali qo'shing.
4. `main.py` ni ishga tushiring (`python main.py`) va Telegram'da botga `/start` yuboring.

## Eslatma
- `pydub` MP3 -> OGG konvertatsiyasi uchun `ffmpeg` talab qiladi. Replit muhitida `ffmpeg` allaqachon mavjud bo'lishi mumkin.
- OpenAI API foydalanishi pullik bo'lishi mumkin — hisobingizdagi balansni tekshiring.
- Bu loyihani GitHub'ga yuklab, Replit orqali "Import from GitHub" bilan biriktirishingiz mumkin.
